const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const fileUpload = require('express-fileupload');
const defaultRouter = require('./src/router');

const app = express();

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
// parse application/json
app.use(bodyParser.json());


app.use(fileUpload({
    createParentPath: true
}));
// check if file is in ./public and serve it
app.use(express.static('public'));

// session management
app.use(session({
    secret: 'very_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

// import the router
app.use(defaultRouter);

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});