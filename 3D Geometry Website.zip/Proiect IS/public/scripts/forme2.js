import * as THREE from 'three';

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();

renderer.setSize(window.innerWidth, window.innerHeight);
document.getElementById('shapeCanvas2').appendChild(renderer.domElement);

// Add shapes (Pyramid and Cylinder)
const pyramidGeometry = new THREE.ConeGeometry(1, 2, 4);
const pyramidMaterial = new THREE.MeshBasicMaterial({ color: 0xffff00 });
const pyramid = new THREE.Mesh(pyramidGeometry, pyramidMaterial);
scene.add(pyramid);

const cylinderGeometry = new THREE.CylinderGeometry(1, 1, 2, 32);
const cylinderMaterial = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
const cylinder = new THREE.Mesh(cylinderGeometry, cylinderMaterial);
cylinder.position.x = 3;
scene.add(cylinder);

camera.position.z = 5;

function animate() {
    requestAnimationFrame(animate);
    pyramid.rotation.y += 0.01;
    cylinder.rotation.x += 0.01;
    renderer.render(scene, camera);
}
animate();
