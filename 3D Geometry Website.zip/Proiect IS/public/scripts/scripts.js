// Function to upload a PDF file
function uploadFile() {
  const formData = new FormData(document.getElementById('uploadForm'));

  fetch('http://localhost:8080/my-webapp/upload', {
      method: 'POST',
      body: formData
  })
  .then(response => {
      if (response.ok) {
          alert('File uploaded successfully!');
          fetchFiles(); // Refresh file list
      } else {
          alert('File upload failed!');
      }
  })
  .catch(err => console.error('Error uploading file:', err));
}

// Function to fetch and display uploaded PDF files
function fetchFiles() {
  fetch('http://localhost:8080/my-webapp/get-uploaded-files')
      .then(response => response.json())
      .then(data => {
          const fileListContainer = document.getElementById('file-list-container');
          fileListContainer.innerHTML = ''; // Clear existing files

          if (data.files && data.files.length > 0) {
              data.files.forEach(file => {
                  const listItem = document.createElement('li');
                  listItem.innerHTML = `<a href="/uploaded-files/${file}" target="_blank">${file}</a>`;
                  fileListContainer.appendChild(listItem);
              });
          } else {
              fileListContainer.innerHTML = '<li>No files available.</li>';
          }
      })
      .catch(err => console.error('Error fetching files:', err));
}
