function droplet() {
    var drop = new Audio(`/button-press.mp3`);
    drop.play();
}

document.addEventListener('click', function(event) {
    if (event.target.tagName === 'BUTTON') {
        droplet();
    }
});