const { Router } = require('express');

const defaultRouter = Router();
const constants = require('./constants');
const authRouter = require('./authRouter');
const apiRouter = require('./apiRouter');

defaultRouter.use(constants.auth, authRouter);
defaultRouter.use(constants.api, apiRouter);

defaultRouter.all(constants.home, (req, res, next) => {
    res.sendFile('main.html', { root: 'public' });
});



module.exports = defaultRouter;