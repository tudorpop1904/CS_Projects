module.exports = {
    home: '/',
    auth: "/auth",
    api: "/api",
}