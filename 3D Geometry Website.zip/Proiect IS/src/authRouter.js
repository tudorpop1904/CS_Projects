const express = require('express');
const bcrypt = require('bcrypt');
const fs = require('fs');
const path = require('path');
const router = express.Router({ mergeParams: true});

const usersFilePath = path.join(__dirname, 'data', 'users.json');

// Helper function to read users from the JSON file
const readUsers = () => {
    if (!fs.existsSync(usersFilePath)) {
        return [];
    }

    const data = fs.readFileSync(usersFilePath);

    if (!data) {
        return [];
    }

    return JSON.parse(data);
};

// Helper function to write users to the JSON file
const writeUsers = (users) => {
    if (!fs.existsSync(usersFilePath)) {
        fs.mkdirSync(path.dirname(usersFilePath), { recursive: true });
    }
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
};

// Login route
router.post('/login', async (req, res) => {
    const { username, password } = req.body;

    const users = readUsers();

    const user = users.find(u => u.username === username);

    if (!user) {
        console.log('User not found');
        return res.status(401).send('Invalid credentials');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (isPasswordValid) {
        req.session.userId = user.id;
        res.status(200).send('Logged in');
    } else {
        console.log('Invalid password');
        res.status(401).send('Invalid credentials');
    }
});

// Register route
router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    const users = readUsers();
    if (users.find(u => u.username === username)) {
        return res.status(400).send('User already exists');
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    users.push({ id: users.length + 1, username, password: hashedPassword, role: 'user' });
    writeUsers(users);
    req.session.userId = users.length+1;
    res.status(200).send('User registered');
});

// Logout route
router.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).send('Could not log out.');
        }
        res.redirect('/');
    });
});

module.exports = router;