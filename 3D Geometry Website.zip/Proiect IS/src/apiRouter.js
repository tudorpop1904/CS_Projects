const express = require('express');
const router = express.Router({mergeParams: true});
const fs = require('fs');
const path = require('path');

const usersFilePath = path.join(__dirname, 'data', 'users.json');

const readUsers = () => {
    if (!fs.existsSync(usersFilePath)) {
        return [];
    }

    const data = fs.readFileSync(usersFilePath);

    if (!data) {
        return [];
    }

    return JSON.parse(data);
};

router.get('/session', (req, res) => {
    let users = readUsers();
    let user = users.find(u => u.id === req.session.userId);
    if (!user) return res.status(200).json({});
    res.json(user);
});

router.post('/upload-course', (req, res) => {
    const file = req.files.file;
    if (!file) {
        return res.status(400).send('No file uploaded');
    }
    const dir = path.join(__dirname, 'data', 'courses');

    // Create directories if they don't exist
    fs.mkdirSync(dir, {recursive: true});

    const filePath = path.join(dir, file.name);
    const fileStream = fs.createWriteStream(filePath);

    fileStream.on('error', (err) => {
        console.error('File Stream Error:', err);
        res.status(500).send('Internal Server Error');
    });

    fileStream.on('finish', () => {
        res.status(200).send('File uploaded successfully');
    });

    fileStream.write(file.data);
    fileStream.end();
});

router.get('/get-courses', (req, res) => {
    const dir = path.join(__dirname, 'data', 'courses');

    if (!fs.existsSync(dir))
        return res.json([]);

    const files = fs.readdirSync(dir);

    res.json(files);
});

router.get('/get-course/:courseName', (req, res) => {
    const courseName = req.params.courseName;
    const dir = path.join(__dirname, 'data', 'courses');
    const filePath = path.join(dir, courseName);

    res.download(filePath);
});


module.exports = router;