package DAO;

import Model.Product;
/**
 * The concrete implementation of {@link DAO.AbstractDAO} for the {@link Model.Product} type
 */
public class ProductDAO extends AbstractDAO<Product> {
}
