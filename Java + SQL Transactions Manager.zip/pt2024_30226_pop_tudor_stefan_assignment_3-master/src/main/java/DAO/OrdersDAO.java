package DAO;
import Model.Orders;
/**
 * The concrete implementation of {@link DAO.AbstractDAO} for the {@link Model.Orders} type
 */
public class OrdersDAO extends AbstractDAO<Orders> {
}
