package DAO;
import Model.Client;

/**
 * The concrete implementation of {@link DAO.AbstractDAO} for the {@link Model.Client} type
 */
public class ClientDAO extends AbstractDAO<Client> {
}
